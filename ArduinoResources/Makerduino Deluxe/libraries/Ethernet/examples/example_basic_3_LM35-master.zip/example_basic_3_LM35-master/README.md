example_basic_3_LM35
====================
